import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { ResumeService } from '../resume/resume.service';
import { AuthService } from '../auth/auth.service';
import { FileUploadModule } from 'primeng/fileupload';
import { TableModule } from 'primeng/table';
import { ButtonModule } from 'primeng/button';
import { ToastModule } from 'primeng/toast';
import { MessageService } from 'primeng/api';
import { CardModule } from 'primeng/card';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [CommonModule, FileUploadModule, TableModule, ButtonModule, ToastModule, CardModule],
  providers: [MessageService],
  templateUrl: './dashboard.html',
  styleUrl: './dashboard.css'
})
export class Dashboard implements OnInit {
  resumes: any[] = [];
  isLoading = false;

  constructor(
    private resumeService: ResumeService, 
    private authService: AuthService,
    private messageService: MessageService,
    private router: Router
  ) {}

  ngOnInit() {
    this.fetchResumes();
  }

  fetchResumes() {
    setTimeout(() => {
      this.isLoading = true;
      
      this.resumeService.getMyResumes().subscribe({
        next: (response: any) => {
          // Check if Spring Boot sent an ApiResponse OR a raw Array
          if (response && response.success) {
            this.resumes = response.data;
          } else if (Array.isArray(response)) {
            // If Spring Boot just returned a List<Resume>
            this.resumes = response; 
          }
          this.isLoading = false;
        },
        error: (err) => {
          console.error('Failed to fetch resumes', err);
          this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Could not load resumes' });
          this.isLoading = false;
        }
      });
    });
  }

onUpload(event: any, fileUpload: any) {
    const file = event.files[0];
    if (file) {
      this.resumeService.uploadResume(file).subscribe({
        next: (response: any) => {
          
          // 1. If backend explicitly says success: true
         if (response && response.success === true) {
            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Resume uploaded successfully!' });
            fileUpload.clear(); 
            this.fetchResumes(); 
          } 
          // 2. If backend explicitly says success: false (Handled ApiResponse Error)
          else if (response && response.success === false) {
            this.messageService.add({ severity: 'error', summary: 'Upload Failed', detail: response.message });
            fileUpload.clear();
          }
          // 3. NEW: If it was caught by GlobalExceptionHandler (ErrorResponse)
          else if (response && response.status >= 400) {
            this.messageService.add({ severity: 'error', summary: 'Server Error', detail: response.message });
            fileUpload.clear();
          }
          // 4. Fallback if it returns the raw Resume object directly
          else if (response && response.id) {
            this.messageService.add({ severity: 'success', summary: 'Success', detail: 'Resume uploaded successfully!' });
            fileUpload.clear(); 
            this.fetchResumes(); 
          } 
          // 5. Truly unknown format
          else {
            console.warn("Unrecognized server response:", response);
            this.messageService.add({ severity: 'error', summary: 'Error', detail: 'Check the browser console.' });
          }
          
        },
        error: (err) => {
          console.error('HTTP Error', err);
          this.messageService.add({ severity: 'error', summary: 'Network Error', detail: 'Check your Spring Boot console.' });
        }
      });
    }
  }

  logout() {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}