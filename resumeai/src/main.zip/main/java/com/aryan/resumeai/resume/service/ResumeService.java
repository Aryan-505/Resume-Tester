package com.aryan.resumeai.resume.service;

import com.aryan.resumeai.auth.entity.User;
import com.aryan.resumeai.auth.repository.UserRepository;
import com.aryan.resumeai.common.exception.ResourceNotFoundException;
import com.aryan.resumeai.resume.dto.ResumeAnalysisRequest;
import com.aryan.resumeai.resume.dto.ResumeAnalysisResponse;
import com.aryan.resumeai.resume.entity.Resume;
import com.aryan.resumeai.resume.repository.ResumeRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.reactive.function.client.WebClient;

import java.io.IOException;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ResumeService {

    private final S3Service fileStorageService; 
    private final ResumeRepository resumeRepository;
    private final UserRepository userRepository;

    @Value("${aws.s3.bucket-name:local}")
    private String bucketName;
    
    @Value("${aws.region:local}")
    private String region;

    public Resume uploadResume(MultipartFile file, String userEmail) throws IOException {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        // 1. Upload the file to S3
        String storedFileName = fileStorageService.uploadFile(file);

        // 2. Generate the access URL
        String fileUrl = String.format("https://%s.s3.%s.amazonaws.com/resumes/%s", bucketName, region, storedFileName);
        
        // 3. Save initial metadata to MySQL
        Resume resume = Resume.builder()
                .user(user)
                .originalFileName(file.getOriginalFilename())
                .storedFileName(storedFileName)
                .fileType(file.getContentType())
                .fileSize(file.getSize())
                .fileUrl(fileUrl)
                .build();

        Resume savedResume = resumeRepository.save(resume);

        // 4. Call the Python AI Service
        try {
            WebClient webClient = WebClient.create("http://localhost:8000");
            
            ResumeAnalysisRequest aiRequest = ResumeAnalysisRequest.builder()
                    .resumeId(savedResume.getId())
                    .fileUrl(savedResume.getFileUrl())
                    .fileType(savedResume.getFileType())
                    .build();

            // Send request and wait for response
            ResumeAnalysisResponse aiResponse = webClient.post()
                    .uri("/api/ai/analyze")
                    .bodyValue(aiRequest)
                    .retrieve()
                    .bodyToMono(ResumeAnalysisResponse.class)
                    .block(); 

            // 5. Update the resume with the AI Score and save again
            if (aiResponse != null && aiResponse.getAtsScore() != null) {
                savedResume.setAtsScore(aiResponse.getAtsScore());
                // Note: We can create database tables for skills and suggestions later!
                resumeRepository.save(savedResume);
            }
            
        } catch (Exception e) {
            System.err.println("Failed to get AI Analysis from Python: " + e.getMessage());
            // We catch the error so the user still sees a successful file upload 
            // even if the AI engine is temporarily down.
        }

        return savedResume;
    }

    public List<Resume> getUserResumes(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        return resumeRepository.findByUserOrderByCreatedAtDesc(user);
    }
}