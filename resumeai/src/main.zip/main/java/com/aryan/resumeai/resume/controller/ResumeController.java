package com.aryan.resumeai.resume.controller;

import com.aryan.resumeai.common.response.ApiResponse;
import com.aryan.resumeai.resume.entity.Resume;
import com.aryan.resumeai.resume.service.ResumeService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/resume")
@RequiredArgsConstructor
public class ResumeController {

    private final ResumeService resumeService;

   @PostMapping("/upload")
    public ResponseEntity<ApiResponse<Resume>> uploadResume(
            @RequestParam("file") MultipartFile file,
            Authentication authentication) {
        
        try {
            Resume savedResume = resumeService.uploadResume(file, authentication.getName());
            
            return ResponseEntity.ok(ApiResponse.<Resume>builder()
                    .success(true)
                    .message("Resume uploaded successfully")
                    .data(savedResume)
                    .build());
                    
        } catch (Exception e) { // <-- Changed from IOException to Exception
            
            e.printStackTrace(); // <-- THIS WILL EXPOSE THE REAL ERROR IN YOUR CONSOLE!
            
            return ResponseEntity.internalServerError().body(ApiResponse.<Resume>builder()
                    .success(false)
                    .message("Failed to upload file: " + e.getMessage())
                    .build());
        }
    }

    @GetMapping("/my-resumes")
    public ResponseEntity<ApiResponse<List<Resume>>> getMyResumes(Authentication authentication) {
        List<Resume> resumes = resumeService.getUserResumes(authentication.getName());
        return ResponseEntity.ok(ApiResponse.<List<Resume>>builder()
                .success(true)
                .message("Resumes fetched successfully")
                .data(resumes)
                .build());
    }
}