import requests
import fitz  # PyMuPDF

def extract_text_from_url(pdf_url: str) -> str:
    """
    Downloads a PDF from a given URL (S3) and extracts its text.
    """
    try:
        # 1. Download the file into memory
        response = requests.get(pdf_url, stream=True)
        response.raise_for_status()
        
        # 2. Read the PDF from the byte stream
        pdf_document = fitz.open(stream=response.content, filetype="pdf")
        
        # 3. Extract text from all pages
        full_text = ""
        for page_num in range(pdf_document.page_count):
            page = pdf_document.load_page(page_num)
            full_text += page.get_text("text") + "\n"
            
        pdf_document.close()
        return full_text

    except requests.exceptions.RequestException as e:
        raise Exception(f"Failed to download PDF from URL: {str(e)}")
    except Exception as e:
        raise Exception(f"Failed to parse PDF: {str(e)}")