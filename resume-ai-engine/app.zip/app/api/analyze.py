from fastapi import APIRouter, HTTPException
from app.models.resume_schema import ResumeAnalyzeRequest, ResumeAnalyzeResponse
from app.services.pdf_parser import extract_text_from_url
import random

router = APIRouter()

@router.post("/analyze", response_model=ResumeAnalyzeResponse)
async def analyze_resume_endpoint(request: ResumeAnalyzeRequest):
    try:
        print(f"Received request to analyze resume ID: {request.resumeId}")
        print(f"Fetching from URL: {request.fileUrl}")
        
        # 1. Extract text from the S3 URL
        resume_text = extract_text_from_url(request.fileUrl)
        
        # Print a snippet to the console to verify it worked!
        print("--- EXTRACTED TEXT PREVIEW ---")
        print(resume_text[:200] + "...") 
        print("------------------------------")
        
        # 2. TODO: Pass `resume_text` to app/services/llm_service.py here
        
        # 3. Return Mock Data for now to test Spring Boot integration
        return ResumeAnalyzeResponse(
            ats_score=round(random.uniform(65.0, 95.0), 2),
            skills_extracted=["Java", "Spring Boot", "Python"],
            missing_skills=["AWS", "Docker"],
            suggestions=["Quantify your achievements with numbers."]
        )
        
    except Exception as e:
        print(f"Error during analysis: {e}")
        raise HTTPException(status_code=500, detail=str(e))